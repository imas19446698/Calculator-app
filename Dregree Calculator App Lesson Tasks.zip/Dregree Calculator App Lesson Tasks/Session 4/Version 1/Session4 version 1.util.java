import java.util.Scanner;

public class SimpleBankingSystem {

    static int MAX_ACCOUNTS = 100; // Maximum number of accounts allowed
    static int accountCount = 0;   // Current number of accounts
    static int[] accountNumbers = new int[MAX_ACCOUNTS];
    static String[] accountHolders = new String[MAX_ACCOUNTS];
    static double[] accountBalances = new double[MAX_ACCOUNTS];
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int choice;

        while (true) {
            System.out.println("\n=== Simple Banking System ===");
            System.out.println("1. Create Account");
            System.out.println("2. Deposit Money");
            System.out.println("3. Withdraw Money");
            System.out.println("4. Check Balance");
            System.out.println("5. List All Accounts");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    createAccount(scanner);
                    break;
                case 2:
                    depositMoney(scanner);
                    break;
                case 3:
                    withdrawMoney(scanner);
                    break;
                case 4:
                    checkBalance(scanner);
                    break;
                case 5:
                    listAllAccounts();
                    break;
                case 6:
                    System.out.println("Thank you for using the banking system. Goodbye!");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        }
    }

    // Method to create a new account
    public static void createAccount(Scanner scanner) {
        if (accountCount >= MAX_ACCOUNTS) {
            System.out.println("Cannot create more accounts. Maximum limit reached.");
            return;
        }
        System.out.print("Enter Account Number: ");
        int accNumber = scanner.nextInt();
        scanner.nextLine(); // Consume leftover newline
        System.out.print("Enter Account Holder's Name: ");
        String accHolder = scanner.nextLine();
        System.out.print("Enter Initial Deposit Amount: ");
        double initialDeposit = scanner.nextDouble();

        if (initialDeposit < 0) {
            System.out.println("Initial deposit cannot be negative.");
            return;
        }

        accountNumbers[accountCount] = accNumber;
        accountHolders[accountCount] = accHolder;
        accountBalances[accountCount] = initialDeposit;
        accountCount++;
        System.out.println("Account created successfully!");
    }

    // Method to deposit money
    public static void depositMoney(Scanner scanner) {
        System.out.print("Enter Account Number: ");
        int accNumber = scanner.nextInt();
        int index = findAccountIndex(accNumber);

        if (index == -1) {
            System.out.println("Account not found!");
            return;
        }

        System.out.print("Enter Deposit Amount: ");
        double depositAmount = scanner.nextDouble();

        if (depositAmount <= 0) {
            System.out.println("Deposit amount must be positive.");
            return;
        }

        accountBalances[index] += depositAmount;
        System.out.println("Money deposited successfully! New Balance: " + accountBalances[index]);
    }

    // Method to withdraw money
    public static void withdrawMoney(Scanner scanner) {
        System.out.print("Enter Account Number: ");
        int accNumber = scanner.nextInt();
        int index = findAccountIndex(accNumber);

        if (index == -1) {
            System.out.println("Account not found!");
            return;
        }

        System.out.print("Enter Withdrawal Amount: ");
        double withdrawAmount = scanner.nextDouble();

        if (withdrawAmount <= 0) {
            System.out.println("Withdrawal amount must be positive.");
            return;
        }

        if (withdrawAmount > accountBalances[index]) {
            System.out.println("Insufficient balance!");
            return;
        }

        accountBalances[index] -= withdrawAmount;
        System.out.println("Money withdrawn successfully! New Balance: " + accountBalances[index]);
    }

    // Method to check account balance
    public static void checkBalance(Scanner scanner) {
        System.out.print("Enter Account Number: ");
        int accNumber = scanner.nextInt();
        int index = findAccountIndex(accNumber);

        if (index == -1) {
            System.out.println("Account not found!");
            return;
        }

        System.out.println("Account Holder: " + accountHolders[index]);
        System.out.println("Account Balance: " + accountBalances[index]);
    }

    // Method to list all accounts
    public static void listAllAccounts() {
        if (accountCount == 0) {
            System.out.println("No accounts available.");
            return;
        }

        System.out.println("\n=== Account List ===");
        for (int i = 0; i < accountCount; i++) {
            System.out.println("Account Number: " + accountNumbers[i]);
            System.out.println("Account Holder: " + accountHolders[i]);
            System.out.println("Account Balance: " + accountBalances[i]);
            System.out.println("-----------------------");
        }
    }

    // Utility method to find the index of an account
    public static int findAccountIndex(int accNumber) {
        for (int i = 0; i < accountCount; i++) {
            if (accountNumbers[i] == accNumber) {
                return i;
            }
        }
        return -1; // Account not found
    }
}

// Code Explanation:
// The program is a menu-driven application that simulates a basic banking system.
// It is implemented in a single class without Object-Oriented Programming (OOP) principles, which means all data and operations are stored in static arrays and methods.
// MAX_ACCOUNTS: Limits the number of accounts to 100.
// accountCount: Keeps track of the current number of accounts created.
// accountNumbers: An array to store the account numbers of all customers.
// accountHolders: An array to store the names of the account holders.
// accountBalances: An array to store the balance of each account.
// Each account's data (number, name, and balance) is stored at the same index across these arrays.
// The program displays a menu with six options for the user.
// while (true): Keeps the program running until the user chooses Exit (6).
// User input determines which method to call based on the switch-case statement.
// If the input is invalid, the program asks the user to try again.


// Below is a example of the code when is ran:

// === Simple Banking System ===
// 1. Create Account
// 2. Deposit Money
// 3. Withdraw Money
// 4. Check Balance
// 5. List All Accounts
// 6. Exit
// Enter your choice: 1
// Enter Account Number: 
// 131166162
// Enter Account Holder's Name: sami ahmad
// Enter Initial Deposit Amount: 4000
// Account created successfully!

// === Simple Banking System ===
// 1. Create Account
// 2. Deposit Money
// 3. Withdraw Money
// 4. Check Balance
// 5. List All Accounts
// 6. Exit
// Enter your choice: 5

// === Account List ===
// Account Number: 131166162
// Account Holder: sami ahmad
// Account Balance: 4000.0
// -----------------------