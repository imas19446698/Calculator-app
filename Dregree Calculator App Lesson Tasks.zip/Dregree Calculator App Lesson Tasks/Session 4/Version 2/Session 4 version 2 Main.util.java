import java.util.ArrayList;
import java.util.Scanner;

public class SimpleBankingSystem {
    private static final int MAX_ACCOUNTS = 100;
    private static ArrayList<BankAccount> accounts = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        int choice;

        while (true) {
            displayMenu();
            choice = scanner.nextInt();
            scanner.nextLine(); // Consume the newline

            switch (choice) {
                case 1:
                    createAccount();
                    break;
                case 2:
                    depositMoney();
                    break;
                case 3:
                    withdrawMoney();
                    break;
                case 4:
                    checkBalance();
                    break;
                case 5:
                    listAllAccounts();
                    break;
                case 6:
                    System.out.println("Thank you for using the banking system. Goodbye!");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        }
    }

    // Display menu
    private static void displayMenu() {
        System.out.println("\n=== Simple Banking System ===");
        System.out.println("1. Create Account");
        System.out.println("2. Deposit Money");
        System.out.println("3. Withdraw Money");
        System.out.println("4. Check Balance");
        System.out.println("5. List All Accounts");
        System.out.println("6. Exit");
        System.out.print("Enter your choice: ");
    }

    // Create a new account
    private static void createAccount() {
        if (accounts.size() >= MAX_ACCOUNTS) {
            System.out.println("Cannot create more accounts. Maximum limit reached.");
            return;
        }

        System.out.print("Enter Account Number: ");
        int accNumber = scanner.nextInt();
        scanner.nextLine(); // Consume leftover newline
        if (findAccount(accNumber) != null) {
            System.out.println("Account with this number already exists!");
            return;
        }

        System.out.print("Enter Account Holder's Name: ");
        String accHolder = scanner.nextLine();

        System.out.print("Enter Initial Deposit Amount: ");
        double initialDeposit = scanner.nextDouble();

        try {
            BankAccount account = new BankAccount(accNumber, accHolder, initialDeposit);
            accounts.add(account);
            System.out.println("Account created successfully!");
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        }
    }

    // Deposit money
    private static void depositMoney() {
        BankAccount account = getAccount();
        if (account != null) {
            System.out.print("Enter Deposit Amount: ");
            double amount = scanner.nextDouble();
            try {
                account.deposit(amount);
                System.out.println("Deposit successful! New Balance: " + account.getBalance());
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
            }
        }
    }

    // Withdraw money
    private static void withdrawMoney() {
        BankAccount account = getAccount();
        if (account != null) {
            System.out.print("Enter Withdrawal Amount: ");
            double amount = scanner.nextDouble();
            try {
                if (account.withdraw(amount)) {
                    System.out.println("Withdrawal successful! New Balance: " + account.getBalance());
                }
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
            }
        }
    }

    // Check balance
    private static void checkBalance() {
        BankAccount account = getAccount();
        if (account != null) {
            System.out.println("\nAccount Holder: " + account.getAccountHolderName());
            System.out.println("Account Balance: " + account.getBalance());
        }
    }

    // List all accounts
    private static void listAllAccounts() {
        if (accounts.isEmpty()) {
            System.out.println("No accounts available.");
            return;
        }

        System.out.println("\n=== Account List ===");
        for (BankAccount account : accounts) {
            account.displayAccountDetails();
        }
    }

    // Utility to get account by user input
    private static BankAccount getAccount() {
        System.out.print("Enter Account Number: ");
        int accNumber = scanner.nextInt();
        BankAccount account = findAccount(accNumber);

        if (account == null) {
            System.out.println("Account not found!");
        }
        return account;
    }

    // Find account by account number
    private static BankAccount findAccount(int accNumber) {
        for (BankAccount account : accounts) {
            if (account.getAccountNumber() == accNumber) {
                return account;
            }
        }
        return null;
    }
}


// Code Explanation
// Abstraction and Encapsulation:

// The BankAccount class encapsulates all details and behaviors of an account.
// Fields such as accountNumber, accountHolderName, and balance are private.
// Public methods like deposit, withdraw, and getters ensure safe access.
// Separation of Concerns:

// The BankAccount class handles account operations.
// The Main class manages the menu system and user interaction.
// Dynamic Storage:

// Instead of using fixed-size arrays, an ArrayList is used to manage bank accounts dynamically.
// Error Handling:

// Negative deposits or withdrawals are prevented using exceptions.
// Reusability:

// Methods like findAccount and getAccount reduce redundancy.

// Below is a example of the code when is ran:


// === Simple Banking System ===
// 1. Create Account
// 2. Deposit Money
// 3. Withdraw Money
// 4. Check Balance
// 5. List All Accounts
// 6. Exit
// Enter your choice: 1

// Enter Account Number: 058164926941
// Enter Account Holder's Name: Sami Ahmad
// Enter Initial Deposit Amount: 500
// Account created successfully!

// === Simple Banking System ===
// 1. Create Account
// 2. Deposit Money
// 3. Withdraw Money
// 4. Check Balance
// 5. List All Accounts
// 6. Exit
// Enter your choice: 2

// Enter Account Number: 058164926941
// Enter Deposit Amount: 200
// Deposit successful! New Balance: 700.0
