public class PasswordValidator {

    public static boolean isValidLength(String password) {
        return password.length() >= 8;
    }

    public static boolean containsUppercase(String password) {
        return password.matches(".*[A-Z].*");
    }

    public static boolean containsLowercase(String password) {
        return password.matches(".*[a-z].*");
    }

    public static boolean containsNumber(String password) {
        return password.matches(".*[0-9].*");
    }

    public static boolean containsSpecialChar(String password) {
        return password.matches(".*[!@#$%^&*()].*");
    }

    public static boolean validate(String password) {
        return isValidLength(password)
                && containsUppercase(password)
                && containsLowercase(password)
                && containsNumber(password)
                && containsSpecialChar(password);
    }
}

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class PasswordValidatorTest {

    @Test
    void testValidPassword() {
        assertTrue(PasswordValidator.validate("Strong1!"));
    }

    @Test
    void testInvalidPasswordTooShort() {
        assertFalse(PasswordValidator.validate("Sh1!"));
    }

    @Test
    void testMissingUppercase() {
        assertFalse(PasswordValidator.validate("strong1!"));
    }

    @Test
    void testMissingLowercase() {
        assertFalse(PasswordValidator.validate("STRONG1!"));
    }

    @Test
    void testMissingNumber() {
        assertFalse(PasswordValidator.validate("Strong!"));
    }

    @Test
    void testMissingSpecialChar() {
        assertFalse(PasswordValidator.validate("Strong1"));
    }
}
