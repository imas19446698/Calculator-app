import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class DegreeClassificationCalculator {

    private JFrame frame;
    private JTextField numModulesField;
    private JPanel inputPanel;
    private JTextArea resultArea;
    private JButton startButton, calculateButton, resetButton;

    private ArrayList<Module> modules;
    private int totalModules;

    public DegreeClassificationCalculator() {
        modules = new ArrayList<>();
        initializeGUI();
    }

    private void initializeGUI() {
        frame = new JFrame("Degree Classification Calculator");
        frame.setSize(800, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        // Top panel for module count input
        JPanel topPanel = new JPanel(new FlowLayout());
        JLabel numModulesLabel = new JLabel("Enter the number of modules:");
        numModulesField = new JTextField(5);
        startButton = new JButton("Start");

        topPanel.add(numModulesLabel);
        topPanel.add(numModulesField);
        topPanel.add(startButton);

        // Input panel for modules
        inputPanel = new JPanel();
        inputPanel.setLayout(new BoxLayout(inputPanel, BoxLayout.Y_AXIS));

        // Result area
        resultArea = new JTextArea(10, 50);
        resultArea.setEditable(false);
        JScrollPane resultScrollPane = new JScrollPane(resultArea);

        // Bottom panel for buttons and result
        JPanel bottomPanel = new JPanel(new BorderLayout());
        JPanel buttonPanel = new JPanel(new FlowLayout());
        calculateButton = new JButton("Calculate Degree Classification");
        resetButton = new JButton("Reset");
        calculateButton.setEnabled(false);

        buttonPanel.add(calculateButton);
        buttonPanel.add(resetButton);

        bottomPanel.add(buttonPanel, BorderLayout.NORTH);
        bottomPanel.add(resultScrollPane, BorderLayout.CENTER);

        // Add listeners
        startButton.addActionListener(new StartListener());
        calculateButton.addActionListener(new CalculateListener());
        resetButton.addActionListener(new ResetListener());

        // Adding components to frame
        frame.add(topPanel, BorderLayout.NORTH);
        frame.add(new JScrollPane(inputPanel), BorderLayout.CENTER);
        frame.add(bottomPanel, BorderLayout.SOUTH);

        frame.setVisible(true);
    }

    private class StartListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                totalModules = Integer.parseInt(numModulesField.getText().trim());
                if (totalModules <= 0) {
                    throw new NumberFormatException("Number of modules must be greater than 0.");
                }
                inputPanel.removeAll();
                modules.clear();

                for (int i = 0; i < totalModules; i++) {
                    JPanel moduleInputPanel = new JPanel(new FlowLayout());
                    JLabel moduleLabel = new JLabel("Module Code:");
                    JTextField moduleCodeField = new JTextField(10);
                    JLabel creditLabel = new JLabel("Credits:");
                    JTextField creditField = new JTextField(5);
                    JLabel marksLabel = new JLabel("Marks:");
                    JTextField marksField = new JTextField(5);

                    moduleInputPanel.add(moduleLabel);
                    moduleInputPanel.add(moduleCodeField);
                    moduleInputPanel.add(creditLabel);
                    moduleInputPanel.add(creditField);
                    moduleInputPanel.add(marksLabel);
                    moduleInputPanel.add(marksField);

                    inputPanel.add(moduleInputPanel);
                }

                inputPanel.revalidate();
                inputPanel.repaint();
                calculateButton.setEnabled(true);

            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(frame, "Error: " + ex.getMessage(), "Input Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private class CalculateListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                modules.clear();
                for (Component component : inputPanel.getComponents()) {
                    if (component instanceof JPanel) {
                        JPanel modulePanel = (JPanel) component;
                        JTextField moduleCodeField = (JTextField) modulePanel.getComponent(1);
                        JTextField creditField = (JTextField) modulePanel.getComponent(3);
                        JTextField marksField = (JTextField) modulePanel.getComponent(5);

                        String moduleCode = moduleCodeField.getText().trim();
                        int credits = Integer.parseInt(creditField.getText().trim());
                        int marks = Integer.parseInt(marksField.getText().trim());

                        int level = getLevelFromModuleCode(moduleCode);
                        if (level == -1) {
                            throw new IllegalArgumentException("Invalid module code format: " + moduleCode);
                        }
                        if (marks < 0 || marks > 100) {
                            throw new IllegalArgumentException("Marks must be between 0 and 100.");
                        }

                        modules.add(new Module(moduleCode, level, credits, marks));
                    }
                }

                StringBuilder resultBuilder = new StringBuilder();
                double totalWeightedAverage = 0;
                int totalCredits = 0;

                // Group modules by level and calculate averages
                for (int level = 1; level <= 9; level++) {
                    double levelTotal = 0;
                    int levelCredits = 0;
                    for (Module module : modules) {
                        if (module.getLevel() == level) {
                            levelTotal += module.getMarks() * module.getCredits();
                            levelCredits += module.getCredits();
                        }
                    }

                    if (levelCredits > 0) {
                        double levelAverage = levelTotal / levelCredits;
                        resultBuilder.append(String.format("Level %d Average: %.2f\n", level, levelAverage));
                        totalWeightedAverage += levelAverage * levelCredits;
                        totalCredits += levelCredits;
                    }
                }

                double overallAverage = totalCredits > 0 ? totalWeightedAverage / totalCredits : 0;

                String classification;
                if (overallAverage >= 70) {
                    classification = "First Class";
                } else if (overallAverage >= 60) {
                    classification = "Upper Second Class (2:1)";
                } else if (overallAverage >= 50) {
                    classification = "Lower Second Class (2:2)";
                } else if (overallAverage >= 40) {
                    classification = "Third Class";
                } else {
                    classification = "Fail";
                }

                resultBuilder.append(String.format("\nOverall Average: %.2f\n", overallAverage));
                resultBuilder.append(String.format("Final Classification: %s\n", classification));

                resultArea.setText(resultBuilder.toString());

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frame, "Error: " + ex.getMessage(), "Calculation Error", JOptionPane.ERROR_MESSAGE);
            }
        }

        private int getLevelFromModuleCode(String moduleCode) {
            for (char c : moduleCode.toCharArray()) {
                if (Character.isDigit(c)) {
                    return Character.getNumericValue(c);
                }
            }
            return -1;
        }
    }

    private class ResetListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            modules.clear();
            numModulesField.setText("");
            inputPanel.removeAll();
            resultArea.setText("");
            calculateButton.setEnabled(false);
            inputPanel.revalidate();
            inputPanel.repaint();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(DegreeClassificationCalculator::new);
    }

    private static class Module {
        private final String moduleCode;
        private final int level;
        private final int credits;
        private final int marks;

        public Module(String moduleCode, int level, int credits, int marks) {
            this.moduleCode = moduleCode;
            this.level = level;
            this.credits = credits;
            this.marks = marks;
        }

        public int getLevel() {
            return level;
        }

        public int getCredits() {
            return credits;
        }

        public int getMarks() {
            return marks;
        }
    }
}
